<?php

$idade = $_POST["idade"];

echo "Você só pode entrar se tiver idade apartir de 18 anos ou ";
echo "A partir de 16 anos, acompanhado <br>";

if ($idade >= 18){
    echo "Voce tem $idade, logo é maior de idade. Pode entrar sozinho <br>";
}else{
    echo "Voce não pode entrar";
}