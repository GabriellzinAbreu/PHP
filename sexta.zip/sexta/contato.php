<?php

echo "Olá mundo <br>";

$idade = 19;
echo $idade;
echo "<br>"; // quebra linha


echo "Operações matematicas <br>";
$soma = 2 + 2;
$subtracao = 4 - 2;
$multiplacacao = 2 * 2;
$divisao = 2 / 2;

echo "2 + 2 é igual a $soma <br>";
echo "4 - 2 é igual a $subtracao<br>";
echo "2 x 2 é igual a $multiplicacao <br>";
echo "2 / 2 é igual a $divisao <br>";


echo "<br>";

//Operadores logicos

$idade = 20; //integer
$falso = false; // boolean
$divisao = 5 / 3; //float
echo "<br>";

echo "Minha idade é $idade <br>"; //aspas duplas identifica automaticamente a variavel $idade
echo 'Minha idade é ' .$idade. '<br>'; //enquanto aspas simples não